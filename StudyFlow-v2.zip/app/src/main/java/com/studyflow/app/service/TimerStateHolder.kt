// ПУТЬ: com/studyflow/app/service/TimerStateHolder.kt

package com.studyflow.app.service

import com.studyflow.app.domain.engine.RuleEngine
import com.studyflow.app.domain.model.CognitiveTier
import com.studyflow.app.domain.model.TimerPhase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.random.Random

/**
 * Неизменяемый снимок состояния активного учебного таймера для реактивной подписки UI и сервисов.
 */
data class TimerSnapshot(
    val phase: TimerPhase = TimerPhase.IDLE,
    val remainingSeconds: Int = 0,
    val totalPhaseSeconds: Int = 0,
    val activeBlockId: Long? = null,
    val activeBlockTitle: String = "",
    val activeBlockTier: CognitiveTier = CognitiveTier.TIER_1,
    val plannedWorkMinutes: Int = RuleEngine.MIN_WORK_DURATION_MINUTES,
    val elapsedWorkSeconds: Int = 0,
    val distractionCount: Int = 0,
    val isRunning: Boolean = false,
    val earlyClosureRecommended: Boolean = false,
    val earlyClosureMessage: String? = null,
    val breakRecommendation: String? = null
) {
    /**
     * Прогресс текущей фазы в диапазоне `0f..1f`.
     */
    val progressFraction: Float
        get() = if (totalPhaseSeconds <= 0) {
            0f
        } else {
            ((totalPhaseSeconds - remainingSeconds).toFloat() / totalPhaseSeconds.toFloat())
                .coerceIn(0f, 1f)
        }
}

/**
 * Потокобезопасный Singleton-держатель состояния таймера на базе [StateFlow].
 * Связывает [TimerForegroundService] с UI-слоем без привязки к контексту Activity.
 */
object TimerStateHolder {

    private val _state = MutableStateFlow(TimerSnapshot())
    val state: StateFlow<TimerSnapshot> = _state.asStateFlow()

    /**
     * Полностью офлайн-пул научно обоснованных микропрактик для восстановительного перерыва
     * (без стимуляции дофаминовой ленты соцсетей).
     */
    private val offlineBreakRecommendations: List<String> = listOf(
        "Посмотрите вдаль через окно минимум 2 минуты — снимите спазм аккомодации глаз.",
        "Пройдитесь по комнате или сделайте короткую прогулку без телефона.",
        "Выпейте стакан чистой воды, чтобы восстановить водный баланс мозга.",
        "Разомните спину, плечи и шею: сделайте 5–6 плавных круговых движений и потянитесь.",
        "Закройте глаза на 3 минуты в тишине — дайте гиппокампу консолидировать изученный материал.",
        "Сделайте 6 циклов спокойного дыхания: вдох 4 секунды, выдох 6 секунд.",
        "Проветрите комнату и сделайте лёгкую разминку кистей и поясницы."
    )

    @Volatile
    private var lastRecommendationIndex: Int = -1

    /**
     * Инициализирует новую учебную сессию в фазе [TimerPhase.WORK].
     */
    fun startWorkSession(
        blockId: Long,
        title: String,
        tier: CognitiveTier,
        plannedWorkMinutes: Int,
        initialDistractions: Int = 0
    ) {
        val clampedMinutes = RuleEngine.clampWorkDurationMinutes(plannedWorkMinutes)
        val totalSeconds = clampedMinutes * 60
        val distractionDecision = RuleEngine.evaluateDistractions(initialDistractions, tier)

        _state.value = TimerSnapshot(
            phase = TimerPhase.WORK,
            remainingSeconds = totalSeconds,
            totalPhaseSeconds = totalSeconds,
            activeBlockId = blockId,
            activeBlockTitle = title,
            activeBlockTier = tier,
            plannedWorkMinutes = clampedMinutes,
            elapsedWorkSeconds = 0,
            distractionCount = initialDistractions.coerceAtLeast(0),
            isRunning = true,
            earlyClosureRecommended = distractionDecision.shouldTriggerEarlyClosure,
            earlyClosureMessage = if (distractionDecision.shouldTriggerEarlyClosure) {
                distractionDecision.recommendation
            } else {
                null
            },
            breakRecommendation = null
        )
    }

    /**
     * Обновляет оставшееся время текущей фазы и накапливает фактически отработанные секунды в фазе WORK.
     */
    fun updateTick(newRemainingSeconds: Int, elapsedDeltaSeconds: Int) {
        _state.update { current ->
            val safeRemaining = newRemainingSeconds.coerceAtLeast(0)
            val updatedWorkSeconds = if (current.phase == TimerPhase.WORK) {
                current.elapsedWorkSeconds + elapsedDeltaSeconds.coerceAtLeast(0)
            } else {
                current.elapsedWorkSeconds
            }
            current.copy(
                remainingSeconds = safeRemaining,
                elapsedWorkSeconds = updatedWorkSeconds
            )
        }
    }

    /**
     * Переводит таймер в следующую фазу жизненного цикла.
     */
    fun transitionToPhase(
        newPhase: TimerPhase,
        durationSeconds: Int,
        isRunning: Boolean = newPhase != TimerPhase.POST_CHECKIN && newPhase != TimerPhase.IDLE
    ) {
        val recommendation = if (newPhase == TimerPhase.BREAK) {
            generateBreakRecommendation()
        } else {
            null
        }

        _state.update { current ->
            current.copy(
                phase = newPhase,
                remainingSeconds = durationSeconds.coerceAtLeast(0),
                totalPhaseSeconds = durationSeconds.coerceAtLeast(0),
                isRunning = isRunning,
                breakRecommendation = recommendation,
                earlyClosureRecommended = if (newPhase == TimerPhase.WORK) {
                    current.earlyClosureRecommended
                } else {
                    false
                }
            )
        }
    }

    /**
     * Устанавливает флаг активности отсчёта (пауза / продолжение).
     */
    fun setRunning(running: Boolean) {
        _state.update { it.copy(isRunning = running) }
    }

    /**
     * Регистрирует нажатие «Мысли блуждают» и мгновенно прогоняет счётчик через [RuleEngine].
     *
     * @return Обновлённое количество отвлечений в текущем блоке.
     */
    fun registerDistraction(): Int {
        var updatedCount = 0
        _state.update { current ->
            val nextCount = current.distractionCount + 1
            updatedCount = nextCount
            val decision = RuleEngine.evaluateDistractions(
                distractionCount = nextCount,
                currentTier = current.activeBlockTier
            )
            current.copy(
                distractionCount = nextCount,
                earlyClosureRecommended = decision.shouldTriggerEarlyClosure,
                earlyClosureMessage = if (decision.shouldTriggerEarlyClosure) {
                    decision.recommendation
                } else {
                    current.earlyClosureMessage
                }
            )
        }
        return updatedCount
    }

    /**
     * Генерирует случайную офлайн-рекомендацию для фазы перерыва,
     * избегая повторения предыдущей подсказки два раза подряд.
     */
    fun generateBreakRecommendation(): String {
        if (offlineBreakRecommendations.size == 1) {
            return offlineBreakRecommendations.first()
        }
        var nextIndex: Int
        do {
            nextIndex = Random.nextInt(offlineBreakRecommendations.size)
        } while (nextIndex == lastRecommendationIndex)

        lastRecommendationIndex = nextIndex
        return offlineBreakRecommendations[nextIndex]
    }

    /**
     * Полностью сбрасывает таймер в состояние [TimerPhase.IDLE].
     */
    fun reset() {
        _state.value = TimerSnapshot()
    }
}
