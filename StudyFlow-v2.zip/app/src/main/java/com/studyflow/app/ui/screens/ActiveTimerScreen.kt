// ПУТЬ: com/studyflow/app/ui/screens/ActiveTimerScreen.kt

package com.studyflow.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studyflow.app.domain.model.TimerPhase
import com.studyflow.app.service.TimerSnapshot
import com.studyflow.app.ui.theme.StudyFlowColors
import com.studyflow.app.ui.theme.SystemBarIconsEffect
import com.studyflow.app.ui.theme.shortLabel
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun ActiveTimerScreen(
    snapshot: TimerSnapshot,
    initialClosureNote: String,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onRegisterDistraction: () -> Unit,
    onTriggerEarlyClosure: () -> Unit,
    onStop: () -> Unit,
    onSaveClosureNote: (blockId: Long, note: String) -> Unit,
    onSubmitPostCheckIn: (blockId: Long, energyAfter: Int) -> Unit
) {
    when (snapshot.phase) {
        TimerPhase.WORK -> WorkPhaseScreen(
            snapshot = snapshot,
            onPause = onPause,
            onResume = onResume,
            onRegisterDistraction = onRegisterDistraction,
            onTriggerEarlyClosure = onTriggerEarlyClosure,
            onStop = onStop
        )

        TimerPhase.CLOSURE -> ClosurePhaseScreen(
            snapshot = snapshot,
            initialClosureNote = initialClosureNote,
            onSaveClosureNote = onSaveClosureNote
        )

        TimerPhase.BREAK -> BreakPhaseScreen(
            snapshot = snapshot
        )

        TimerPhase.POST_CHECKIN -> PostCheckInScreen(
            snapshot = snapshot,
            onSubmitPostCheckIn = onSubmitPostCheckIn,
            onFallbackStop = onStop
        )

        TimerPhase.IDLE -> Unit
    }
}

@Composable
private fun WorkPhaseScreen(
    snapshot: TimerSnapshot,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onRegisterDistraction: () -> Unit,
    onTriggerEarlyClosure: () -> Unit,
    onStop: () -> Unit
) {
    SystemBarIconsEffect(
        darkStatusBarIcons = false,
        darkNavigationBarIcons = false
    )

    var showFinishDialog by rememberSaveable { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudyFlowColors.ForestGreen)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Верхняя строка: название предмета и кнопка «Отвлёкся (N)»
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 12.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = snapshot.activeBlockTitle.ifBlank { "Учебный блок" },
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = snapshot.activeBlockTier.shortLabel(),
                    style = MaterialTheme.typography.labelMedium,
                    color = StudyFlowColors.OnForestSecondary
                )
            }

            Surface(
                onClick = onRegisterDistraction,
                color = Color.White.copy(alpha = 0.14f),
                shape = RoundedCornerShape(999.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.22f))
            ) {
                Text(
                    text = "Отвлёкся (${snapshot.distractionCount})",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }

        // По центру: гигантский белый таймер и тонкая полоска прогресса
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = formatTimerSeconds(snapshot.remainingSeconds),
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 76.sp,
                    lineHeight = 82.sp,
                    fontWeight = FontWeight.Light,
                    fontFeatureSettings = "tnum",
                    letterSpacing = (-2).sp
                ),
                color = Color.White
            )

            LinearProgressIndicator(
                progress = { snapshot.progressFraction },
                modifier = Modifier
                    .fillMaxWidth(0.58f)
                    .height(4.dp)
                    .clip(RoundedCornerShape(999.dp)),
                color = Color.White,
                trackColor = Color.White.copy(alpha = 0.22f),
                strokeCap = StrokeCap.Round
            )

            Text(
                text = if (snapshot.isRunning) "В фокусе" else "На паузе",
                style = MaterialTheme.typography.bodyMedium,
                color = StudyFlowColors.OnForestSecondary
            )

            // При >= 2 отвлечениях: мягкая светлая плашка «Сбавить темп и закрыть мысль»
            if (snapshot.earlyClosureRecommended) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    onClick = onTriggerEarlyClosure,
                    color = StudyFlowColors.SageSurface,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                text = "Сбавить темп и закрыть мысль",
                                style = MaterialTheme.typography.labelLarge,
                                color = StudyFlowColors.ForestGreen
                            )
                            Text(
                                text = "Перейти к 3-минутной записи остановки сейчас",
                                style = MaterialTheme.typography.bodyMedium,
                                color = StudyFlowColors.TextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "→",
                            style = MaterialTheme.typography.titleLarge,
                            color = StudyFlowColors.ForestGreen
                        )
                    }
                }
            }
        }

        // Внизу: аккуратные кнопки «Пауза / Продолжить» и «Завершить»
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = { if (snapshot.isRunning) onPause() else onResume() },
                modifier = Modifier
                    .weight(1.3f)
                    .height(54.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = StudyFlowColors.ForestGreen
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
            ) {
                if (snapshot.isRunning) {
                    PauseGlyph(color = StudyFlowColors.ForestGreen)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Пауза",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                } else {
                    Icon(
                        imageVector = Icons.Rounded.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Продолжить",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            OutlinedButton(
                onClick = { showFinishDialog = true },
                modifier = Modifier
                    .weight(1f)
                    .height(54.dp),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.38f)),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = Color.Transparent,
                    contentColor = Color.White
                )
            ) {
                Text(
                    text = "Завершить",
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }
    }

    if (showFinishDialog) {
        AlertDialog(
            onDismissRequest = { showFinishDialog = false },
            containerColor = StudyFlowColors.PureWhite,
            shape = RoundedCornerShape(20.dp),
            title = {
                Text(
                    text = "Завершить блок сейчас?",
                    style = MaterialTheme.typography.headlineSmall,
                    color = StudyFlowColors.TextPrimary
                )
            },
            text = {
                Text(
                    text = "Отработанное время сохранится, но запись остановки и перерыв будут пропущены.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = StudyFlowColors.TextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showFinishDialog = false
                        onStop()
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudyFlowColors.Danger,
                        contentColor = Color.White
                    )
                ) {
                    Text("Завершить")
                }
            },
            dismissButton = {
                TextButton(onClick = { showFinishDialog = false }) {
                    Text("Остаться", color = StudyFlowColors.ForestGreen)
                }
            }
        )
    }
}

@Composable
private fun ClosurePhaseScreen(
    snapshot: TimerSnapshot,
    initialClosureNote: String,
    onSaveClosureNote: (blockId: Long, note: String) -> Unit
) {
    SystemBarIconsEffect(
        darkStatusBarIcons = true,
        darkNavigationBarIcons = true
    )

    val blockId = snapshot.activeBlockId
    var noteText by rememberSaveable(blockId) { mutableStateOf(initialClosureNote) }
    var lastSavedNote by remember(blockId) { mutableStateOf(initialClosureNote) }
    val latestNote by rememberUpdatedState(noteText)
    val latestSaveCallback by rememberUpdatedState(onSaveClosureNote)

    // Тихое автосохранение в Room
    LaunchedEffect(blockId, noteText) {
        if (blockId != null && noteText != lastSavedNote) {
            delay(450L)
            latestSaveCallback(blockId, noteText)
            lastSavedNote = noteText
        }
    }

    // Финальное сохранение при переходе к перерыву
    DisposableEffect(blockId) {
        onDispose {
            if (blockId != null && latestNote.isNotBlank()) {
                latestSaveCallback(blockId, latestNote)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudyFlowColors.SageSurface)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "Закрытие мысли",
                style = MaterialTheme.typography.labelLarge,
                color = StudyFlowColors.TextSecondary
            )
            Text(
                text = formatTimerSeconds(snapshot.remainingSeconds),
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 58.sp,
                    fontWeight = FontWeight.Light,
                    fontFeatureSettings = "tnum"
                ),
                color = StudyFlowColors.ForestGreen
            )
        }

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "На чём остановился?",
                style = MaterialTheme.typography.headlineMedium,
                color = StudyFlowColors.TextPrimary
            )

            OutlinedTextField(
                value = noteText,
                onValueChange = { noteText = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp),
                shape = RoundedCornerShape(16.dp),
                placeholder = {
                    Text(
                        text = "Коротко запишите точку остановки и первый шаг на следующий раз...",
                        color = StudyFlowColors.TextMuted
                    )
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = StudyFlowColors.PureWhite,
                    unfocusedContainerColor = StudyFlowColors.PureWhite,
                    focusedBorderColor = StudyFlowColors.ForestGreen,
                    unfocusedBorderColor = StudyFlowColors.SageBorder,
                    cursorColor = StudyFlowColors.ForestGreen,
                    focusedTextColor = StudyFlowColors.TextPrimary,
                    unfocusedTextColor = StudyFlowColors.TextPrimary
                )
            )

            val statusText = when {
                noteText.isBlank() -> "Заметка сохраняется автоматически"
                noteText == lastSavedNote -> "Сохранено"
                else -> "Сохранение..."
            }
            Text(
                text = statusText,
                style = MaterialTheme.typography.labelMedium,
                color = if (noteText.isNotBlank() && noteText == lastSavedNote) {
                    StudyFlowColors.ForestGreen
                } else {
                    StudyFlowColors.TextMuted
                }
            )
        }

        Spacer(modifier = Modifier.weight(1f, fill = true))

        Text(
            text = "Через пару минут автоматически начнётся перерыв.",
            style = MaterialTheme.typography.bodyMedium,
            color = StudyFlowColors.TextSecondary,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun BreakPhaseScreen(
    snapshot: TimerSnapshot
) {
    SystemBarIconsEffect(
        darkStatusBarIcons = false,
        darkNavigationBarIcons = false
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudyFlowColors.BreakSageDark)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = "Перерыв",
                style = MaterialTheme.typography.titleLarge,
                color = StudyFlowColors.SageSurface
            )
            Text(
                text = "Отложите телефон и дайте глазам отдохнуть",
                style = MaterialTheme.typography.bodyMedium,
                color = StudyFlowColors.SageSurface.copy(alpha = 0.72f),
                textAlign = TextAlign.Center
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = formatTimerSeconds(snapshot.remainingSeconds),
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 72.sp,
                    fontWeight = FontWeight.Light,
                    fontFeatureSettings = "tnum"
                ),
                color = StudyFlowColors.SageSurface
            )

            LinearProgressIndicator(
                progress = { snapshot.progressFraction },
                modifier = Modifier
                    .fillMaxWidth(0.55f)
                    .height(4.dp)
                    .clip(RoundedCornerShape(999.dp)),
                color = StudyFlowColors.SageSurface.copy(alpha = 0.85f),
                trackColor = Color.White.copy(alpha = 0.16f),
                strokeCap = StrokeCap.Round
            )
        }

        // Одна спокойная карточка с советом — без кнопки пропуска
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = StudyFlowColors.BreakCardSurface,
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.dp, StudyFlowColors.BreakCardBorder)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Идея на перерыв",
                    style = MaterialTheme.typography.labelLarge,
                    color = StudyFlowColors.SageSurface.copy(alpha = 0.72f)
                )
                Text(
                    text = snapshot.breakRecommendation
                        ?: "Посмотрите вдаль через окно, пройдитесь по комнате и выпейте стакан воды.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = StudyFlowColors.SageSurface
                )
            }
        }
    }
}

@Composable
private fun PostCheckInScreen(
    snapshot: TimerSnapshot,
    onSubmitPostCheckIn: (blockId: Long, energyAfter: Int) -> Unit,
    onFallbackStop: () -> Unit
) {
    SystemBarIconsEffect(
        darkStatusBarIcons = true,
        darkNavigationBarIcons = true
    )

    var selectedEnergy by rememberSaveable { mutableIntStateOf(0) }
    val options = listOf(
        1 to "Совсем нет сил",
        2 to "Устал",
        3 to "Нормально",
        4 to "Хорошо",
        5 to "Полон сил"
    )
    val workedMinutes = (snapshot.elapsedWorkSeconds / 60.0).roundToInt()
        .coerceAtLeast(if (snapshot.elapsedWorkSeconds > 0) 1 else 0)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudyFlowColors.SageSurface)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "Как силы после блока?",
                style = MaterialTheme.typography.headlineMedium,
                color = StudyFlowColors.TextPrimary,
                textAlign = TextAlign.Center
            )
            Text(
                text = "${snapshot.activeBlockTitle.ifBlank { "Учебный блок" }} · $workedMinutes мин",
                style = MaterialTheme.typography.bodyMedium,
                color = StudyFlowColors.TextSecondary,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 5 крупных кнопок оценки (1–5)
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            options.forEach { (level, label) ->
                val isSelected = selectedEnergy == level
                val bgColor = if (isSelected) {
                    StudyFlowColors.ForestGreen
                } else {
                    StudyFlowColors.PureWhite
                }
                val contentColor = if (isSelected) {
                    Color.White
                } else {
                    StudyFlowColors.TextPrimary
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(bgColor)
                        .border(
                            width = 1.dp,
                            color = if (isSelected) {
                                StudyFlowColors.ForestGreen
                            } else {
                                StudyFlowColors.SageBorder
                            },
                            shape = RoundedCornerShape(14.dp)
                        )
                        .clickable { selectedEnergy = level }
                        .padding(horizontal = 18.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Text(
                                text = level.toString(),
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) Color.White else StudyFlowColors.ForestGreen
                            )
                            Text(
                                text = label,
                                style = MaterialTheme.typography.titleMedium,
                                color = contentColor
                            )
                        }

                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Rounded.Check,
                                contentDescription = null,
                                tint = Color.White
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Зелёная кнопка «Готово»
        Button(
            onClick = {
                val blockId = snapshot.activeBlockId
                if (blockId != null && selectedEnergy in 1..5) {
                    onSubmitPostCheckIn(blockId, selectedEnergy)
                } else {
                    onFallbackStop()
                }
            },
            enabled = selectedEnergy in 1..5,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = StudyFlowColors.ForestGreen,
                contentColor = Color.White,
                disabledContainerColor = StudyFlowColors.SageBorder,
                disabledContentColor = StudyFlowColors.TextMuted
            ),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
        ) {
            Text(
                text = "Готово",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun PauseGlyph(color: Color) {
    Canvas(modifier = Modifier.size(16.dp)) {
        val barWidth = size.width * 0.28f
        val barHeight = size.height * 0.82f
        val topOffset = (size.height - barHeight) / 2f
        val radius = CornerRadius(2.dp.toPx(), 2.dp.toPx())

        drawRoundRect(
            color = color,
            topLeft = Offset(size.width * 0.14f, topOffset),
            size = Size(barWidth, barHeight),
            cornerRadius = radius
        )
        drawRoundRect(
            color = color,
            topLeft = Offset(size.width * 0.58f, topOffset),
            size = Size(barWidth, barHeight),
            cornerRadius = radius
        )
    }
}

private fun formatTimerSeconds(totalSeconds: Int): String {
    val safe = totalSeconds.coerceAtLeast(0)
    val minutes = safe / 60
    val seconds = safe % 60
    return String.format(Locale.US, "%02d:%02d", minutes, seconds)
}
