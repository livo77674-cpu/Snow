// ПУТЬ: com/studyflow/app/data/local/AppDatabase.kt

package com.studyflow.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.studyflow.app.domain.model.BlockStatus

/**
 * Конвертеры пользовательских типов для Room (KSP).
 */
class StudyTypeConverters {

    @TypeConverter
    fun fromBlockStatus(status: BlockStatus): String = status.name

    @TypeConverter
    fun toBlockStatus(value: String): BlockStatus = BlockStatus.fromName(value)
}

/**
 * Локальная офлайн-база данных StudyFlow на базе Android Room.
 */
@Database(
    entities = [
        DailyStateEntity::class,
        StudyBlockEntity::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(StudyTypeConverters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun studyDao(): StudyDao

    companion object {
        private const val DATABASE_NAME = "studyflow_offline.db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * Потокобезопасный Singleton-доступ к экземпляру БД.
         * Использует [Context.getApplicationContext] во избежание утечек памяти.
         */
        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context.applicationContext).also { db ->
                    INSTANCE = db
                }
            }
        }

        private fun buildDatabase(appContext: Context): AppDatabase {
            return Room.databaseBuilder(
                appContext,
                AppDatabase::class.java,
                DATABASE_NAME
            )
                .fallbackToDestructiveMigration()
                .build()
        }
    }
}
