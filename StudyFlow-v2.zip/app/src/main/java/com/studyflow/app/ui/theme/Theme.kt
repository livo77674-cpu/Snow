// ПУТЬ: com/studyflow/app/ui/theme/Theme.kt

package com.studyflow.app.ui.theme

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.studyflow.app.domain.model.CognitiveTier

/**
 * Спокойная минималистичная палитра StudyFlow v2 в стиле Yeolpumta (YPT):
 * глубокий хвойно-зелёный верх, чистый белый фон и мягкие шалфейные поверхности.
 */
object StudyFlowColors {
    // Ключевые фоны
    val ForestGreen = Color(0xFF0E5A36)
    val ForestGreenDark = Color(0xFF0A4428)
    val BreakSageDark = Color(0xFF1B3B2B)
    val BreakCardSurface = Color(0xFF244A37)
    val BreakCardBorder = Color(0xFF33624A)

    val PureWhite = Color(0xFFFFFFFF)
    val SageSurface = Color(0xFFF4F7F2)
    val SageBorder = Color(0xFFDCE3D8)
    val DividerLight = Color(0xFFECEFE9)

    // Текст
    val TextPrimary = Color(0xFF141C18)
    val TextSecondary = Color(0xFF5D6B63)
    val TextMuted = Color(0xFF8C9A92)
    val OnForestPrimary = Color(0xFFFFFFFF)
    val OnForestSecondary = Color(0xCCFFFFFF)

    // Цвета уровней нагрузки (Сложное / Практика / Лёгкое)
    val Tier1Color = Color(0xFF0E5A36)
    val Tier1SoftBg = Color(0xFFE7F2EC)

    val Tier2Color = Color(0xFFD97706)
    val Tier2SoftBg = Color(0xFFFEF3E2)

    val Tier3Color = Color(0xFF4A7C8C)
    val Tier3SoftBg = Color(0xFFEAF2F5)

    // Мягкие статусные акценты
    val WarningBg = Color(0xFFFFF8ED)
    val WarningBorder = Color(0xFFF2D6AE)
    val WarningText = Color(0xFF8A4B08)
    val Danger = Color(0xFFC53929)
}

/**
 * Акцентный цвет для кружка Play и индикаторов уровня нагрузки.
 */
fun CognitiveTier.accentColor(): Color = when (this) {
    CognitiveTier.TIER_1 -> StudyFlowColors.Tier1Color
    CognitiveTier.TIER_2 -> StudyFlowColors.Tier2Color
    CognitiveTier.TIER_3 -> StudyFlowColors.Tier3Color
}

/**
 * Мягкий фоновый оттенок для выбранного чипа уровня нагрузки.
 */
fun CognitiveTier.softBackgroundColor(): Color = when (this) {
    CognitiveTier.TIER_1 -> StudyFlowColors.Tier1SoftBg
    CognitiveTier.TIER_2 -> StudyFlowColors.Tier2SoftBg
    CognitiveTier.TIER_3 -> StudyFlowColors.Tier3SoftBg
}

/**
 * Простое человекочитаемое название уровня нагрузки на русском.
 */
fun CognitiveTier.shortLabel(): String = when (this) {
    CognitiveTier.TIER_1 -> "Сложное"
    CognitiveTier.TIER_2 -> "Практика"
    CognitiveTier.TIER_3 -> "Лёгкое"
}

/**
 * Короткое пояснение для диалога выбора предмета.
 */
fun CognitiveTier.humanHint(): String = when (this) {
    CognitiveTier.TIER_1 -> "Новые темы и глубокий разбор"
    CognitiveTier.TIER_2 -> "Задачи, повторение и закрепление"
    CognitiveTier.TIER_3 -> "Спокойное чтение, заметки и обзор"
}

/**
 * Адаптивная настройка цвета системных иконок статус-бара и навигационной панели
 * в зависимости от того, тёмный сейчас верхний фон (#0E5A36 / #1B3B2B) или светлый (#F4F7F2 / #FFFFFF).
 */
@Composable
fun SystemBarIconsEffect(
    darkStatusBarIcons: Boolean,
    darkNavigationBarIcons: Boolean
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val activity = view.context.findActivity() ?: return@SideEffect
            val insetsController = WindowCompat.getInsetsController(activity.window, view)
            insetsController.isAppearanceLightStatusBars = darkStatusBarIcons
            insetsController.isAppearanceLightNavigationBars = darkNavigationBarIcons
        }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private val StudyFlowLightColorScheme = lightColorScheme(
    primary = StudyFlowColors.ForestGreen,
    onPrimary = Color.White,
    primaryContainer = StudyFlowColors.Tier1SoftBg,
    onPrimaryContainer = StudyFlowColors.ForestGreen,
    secondary = StudyFlowColors.Tier3Color,
    onSecondary = Color.White,
    secondaryContainer = StudyFlowColors.SageSurface,
    onSecondaryContainer = StudyFlowColors.TextPrimary,
    tertiary = StudyFlowColors.Tier2Color,
    onTertiary = Color.White,
    background = StudyFlowColors.PureWhite,
    onBackground = StudyFlowColors.TextPrimary,
    surface = StudyFlowColors.PureWhite,
    onSurface = StudyFlowColors.TextPrimary,
    surfaceVariant = StudyFlowColors.SageSurface,
    onSurfaceVariant = StudyFlowColors.TextSecondary,
    outline = StudyFlowColors.SageBorder,
    outlineVariant = StudyFlowColors.DividerLight,
    error = StudyFlowColors.Danger,
    onError = Color.White
)

private val StudyFlowTypography = Typography(
    displayLarge = TextStyle(
        fontWeight = FontWeight.Light,
        fontSize = 62.sp,
        lineHeight = 68.sp,
        letterSpacing = (-1.5).sp,
        fontFeatureSettings = "tnum"
    ),
    displayMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 48.sp,
        lineHeight = 54.sp,
        letterSpacing = (-1.0).sp,
        fontFeatureSettings = "tnum"
    ),
    headlineMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 24.sp,
        lineHeight = 30.sp,
        letterSpacing = (-0.3).sp
    ),
    headlineSmall = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp,
        lineHeight = 26.sp
    ),
    titleLarge = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp,
        lineHeight = 24.sp
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    bodyLarge = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 19.sp
    ),
    labelLarge = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        lineHeight = 18.sp
    ),
    labelMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp
    ),
    labelSmall = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 14.sp
    )
)

@Composable
fun StudyFlowTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = StudyFlowLightColorScheme,
        typography = StudyFlowTypography,
        content = content
    )
}
