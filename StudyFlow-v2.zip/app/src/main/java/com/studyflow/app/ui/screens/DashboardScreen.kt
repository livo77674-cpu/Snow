// ПУТЬ: com/studyflow/app/ui/screens/DashboardScreen.kt

package com.studyflow.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studyflow.app.data.local.DailyStateEntity
import com.studyflow.app.data.local.StudyBlockEntity
import com.studyflow.app.domain.engine.EnergyAdaptationAction
import com.studyflow.app.domain.engine.RuleEngine
import com.studyflow.app.domain.model.BlockStatus
import com.studyflow.app.domain.model.CognitiveTier
import com.studyflow.app.ui.theme.StudyFlowColors
import com.studyflow.app.ui.theme.SystemBarIconsEffect
import com.studyflow.app.ui.theme.accentColor
import com.studyflow.app.ui.theme.humanHint
import com.studyflow.app.ui.theme.shortLabel
import com.studyflow.app.ui.theme.softBackgroundColor
import com.studyflow.app.ui.viewmodel.StudyUiState
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

private enum class DashboardTab(val title: String) {
    TIMER("Таймер"),
    SUMMARY("Сводка дня")
}

@Composable
fun DashboardScreen(
    uiState: StudyUiState,
    onSaveMorningSleep: (Int) -> Unit,
    onAddBlock: (title: String, tier: CognitiveTier, plannedMinutes: Int) -> Unit,
    onDeleteBlock: (StudyBlockEntity) -> Unit,
    onStartBlock: (block: StudyBlockEntity, energyBefore: Int) -> Unit,
    onApplyEnergyAdaptation: (List<StudyBlockEntity>) -> Unit,
    onDismissSnackbar: () -> Unit
) {
    // Белые иконки в зелёном статус-баре, тёмные иконки на белой нижней панели
    SystemBarIconsEffect(
        darkStatusBarIcons = false,
        darkNavigationBarIcons = true
    )

    val snackbarHostState = remember { SnackbarHostState() }
    var activeTabIndex by rememberSaveable { mutableIntStateOf(0) }
    var showAddSubjectDialog by rememberSaveable { mutableStateOf(false) }
    var showSleepDialog by rememberSaveable { mutableStateOf(false) }
    var blockPendingStart by remember { mutableStateOf<StudyBlockEntity?>(null) }

    val activeTab = DashboardTab.entries[activeTabIndex.coerceIn(0, 1)]

    LaunchedEffect(uiState.snackbarMessage) {
        val raw = uiState.snackbarMessage
        if (!raw.isNullOrBlank()) {
            val friendly = sanitizeSystemMessage(raw)
            snackbarHostState.showSnackbar(friendly)
            onDismissSnackbar()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = StudyFlowColors.PureWhite,
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = StudyFlowColors.TextPrimary,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(14.dp)
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding())
        ) {
            // Верхняя треть экрана: спокойный тёмно-зелёный фон с датой, иконкой сна и гигантским счётчиком 0:00:00
            GreenYptHeader(
                dateIso = uiState.todayDate,
                dailyState = uiState.dailyState,
                totalMinutesToday = uiState.totalMinutesToday,
                onSleepClick = { showSleepDialog = true }
            )

            // Две вкладки на чистом белом фоне: «Таймер» и «Сводка дня»
            DashboardTabBar(
                activeTab = activeTab,
                onSelectTab = { activeTabIndex = it.ordinal }
            )

            // Содержимое активной вкладки
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(StudyFlowColors.PureWhite)
            ) {
                when (activeTab) {
                    DashboardTab.TIMER -> TimerListTab(
                        uiState = uiState,
                        onOpenSleepCheckIn = { showSleepDialog = true },
                        onApplyAdaptation = { onApplyEnergyAdaptation(uiState.blocks) },
                        onRowClick = { block ->
                            if (block.status != BlockStatus.COMPLETED) {
                                blockPendingStart = block
                            }
                        },
                        onDeleteBlock = onDeleteBlock,
                        onAddSubjectClick = { showAddSubjectDialog = true }
                    )

                    DashboardTab.SUMMARY -> DailySummaryTab(
                        uiState = uiState
                    )
                }
            }
        }
    }

    // Диалог утренней/текущей оценки сна
    if (showSleepDialog) {
        SleepQualityDialog(
            initialQuality = uiState.dailyState?.sleepQuality ?: 4,
            onDismiss = { showSleepDialog = false },
            onSave = { score ->
                showSleepDialog = false
                onSaveMorningSleep(score)
            }
        )
    }

    // Диалог добавления нового предмета
    if (showAddSubjectDialog) {
        AddSubjectDialog(
            isHardBlocked = uiState.tier1Overload.isTier1Blocked ||
                uiState.deloadEvaluation.isDeloadRecommended,
            onDismiss = { showAddSubjectDialog = false },
            onConfirm = { title, tier, minutes ->
                showAddSubjectDialog = false
                onAddBlock(title, tier, minutes)
            }
        )
    }

    // Однотаповый выбор самочувствия (1–5) перед стартом предмета
    blockPendingStart?.let { targetBlock ->
        PreStartFeelingDialog(
            block = targetBlock,
            onDismiss = { blockPendingStart = null },
            onSelectAndStart = { feeling ->
                blockPendingStart = null
                onStartBlock(targetBlock, feeling)
            }
        )
    }
}

@Composable
private fun GreenYptHeader(
    dateIso: String,
    dailyState: DailyStateEntity?,
    totalMinutesToday: Int,
    onSleepClick: () -> Unit
) {
    val formattedDate = remember(dateIso) { formatHumanDate(dateIso) }
    val formattedTotal = remember(totalMinutesToday) { formatMinutesAsHms(totalMinutesToday) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudyFlowColors.ForestGreen)
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
            .padding(top = 10.dp, bottom = 30.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Верхняя строка: дата слева, компактная иконка оценки сна справа
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = formattedDate,
                style = MaterialTheme.typography.titleMedium,
                color = StudyFlowColors.OnForestSecondary
            )

            Surface(
                onClick = onSleepClick,
                color = Color.White.copy(alpha = 0.14f),
                shape = RoundedCornerShape(999.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CrescentMoonIcon(
                        color = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = if (dailyState != null) {
                            "Сон ${dailyState.sleepQuality}/5"
                        } else {
                            "Сон"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(26.dp))

        // Гигантский чистый цифровой счётчик времени за день в формате 0:00:00 (tnum)
        Text(
            text = formattedTotal,
            style = MaterialTheme.typography.displayLarge.copy(
                fontSize = 60.sp,
                fontWeight = FontWeight.Light,
                fontFeatureSettings = "tnum",
                letterSpacing = (-1.5).sp
            ),
            color = StudyFlowColors.OnForestPrimary,
            maxLines = 1
        )

        Spacer(modifier = Modifier.height(6.dp))

        val subtitle = when {
            dailyState == null -> "Сегодня"
            dailyState.consecutiveWorkDays > 1 -> "Сегодня · ${dailyState.consecutiveWorkDays}-й день подряд"
            else -> "Сегодня"
        }
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = StudyFlowColors.OnForestSecondary
        )
    }
}

@Composable
private fun DashboardTabBar(
    activeTab: DashboardTab,
    onSelectTab: (DashboardTab) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudyFlowColors.PureWhite)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            DashboardTab.entries.forEach { tab ->
                val isSelected = tab == activeTab
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxSize()
                        .clickable { onSelectTab(tab) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = tab.title,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
                        color = if (isSelected) {
                            StudyFlowColors.ForestGreen
                        } else {
                            StudyFlowColors.TextMuted
                        }
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.55f)
                            .height(2.5.dp)
                            .clip(RoundedCornerShape(topStart = 2.dp, topEnd = 2.dp))
                            .background(
                                if (isSelected) StudyFlowColors.ForestGreen else Color.Transparent
                            )
                    )
                }
            }
        }
        HorizontalDivider(color = StudyFlowColors.DividerLight, thickness = 1.dp)
    }
}

@Composable
private fun TimerListTab(
    uiState: StudyUiState,
    onOpenSleepCheckIn: () -> Unit,
    onApplyAdaptation: () -> Unit,
    onRowClick: (StudyBlockEntity) -> Unit,
    onDeleteBlock: (StudyBlockEntity) -> Unit,
    onAddSubjectClick: () -> Unit
) {
    val overloadHint = remember(
        uiState.deloadEvaluation,
        uiState.tier1Overload,
        uiState.energyDropEvaluation
    ) {
        resolveSingleOverloadHint(uiState)
    }
    val hasPlannedBlocks = remember(uiState.blocks) {
        uiState.blocks.any { it.status == BlockStatus.PLANNED }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudyFlowColors.PureWhite)
    ) {
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(top = 8.dp, bottom = 16.dp)
        ) {
            // Если сон ещё не отмечен, показываем аккуратную строку-напоминание
            if (!uiState.isLoading && uiState.dailyState == null) {
                item(key = "sleep_prompt") {
                    CompactHintStrip(
                        text = "Отметьте качество сна, чтобы точно рассчитать запас сил на день.",
                        actionLabel = "Оценить",
                        isWarm = false,
                        onActionClick = onOpenSleepCheckIn
                    )
                }
            }

            // Одна компактная плашка-подсказка при перегрузке (RuleEngine)
            if (overloadHint != null) {
                item(key = "overload_hint") {
                    CompactHintStrip(
                        text = overloadHint,
                        actionLabel = if (hasPlannedBlocks) "Облегчить план" else null,
                        isWarm = true,
                        onActionClick = if (hasPlannedBlocks) onApplyAdaptation else null
                    )
                }
            }

            if (uiState.blocks.isEmpty()) {
                item(key = "empty_list") {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 32.dp, vertical = 52.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Список предметов пуст",
                            style = MaterialTheme.typography.titleMedium,
                            color = StudyFlowColors.TextPrimary
                        )
                        Text(
                            text = "Добавьте первый предмет ниже и нажмите на строку, чтобы запустить таймер.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = StudyFlowColors.TextSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                itemsIndexed(
                    items = uiState.blocks,
                    key = { _, block -> block.id }
                ) { index, block ->
                    MinimalSubjectRow(
                        block = block,
                        onClick = { onRowClick(block) },
                        onDeleteClick = { onDeleteBlock(block) }
                    )
                    if (index < uiState.blocks.lastIndex) {
                        HorizontalDivider(
                            modifier = Modifier.padding(start = 74.dp, end = 20.dp),
                            color = StudyFlowColors.DividerLight,
                            thickness = 0.75.dp
                        )
                    }
                }
            }
        }

        // Одна широкая зелёная кнопка «Добавить предмет» внизу
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(StudyFlowColors.PureWhite)
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp)
        ) {
            Button(
                onClick = onAddSubjectClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = StudyFlowColors.ForestGreen,
                    contentColor = Color.White
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Add,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Добавить предмет",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun CompactHintStrip(
    text: String,
    actionLabel: String?,
    isWarm: Boolean,
    onActionClick: (() -> Unit)?
) {
    val bgColor = if (isWarm) StudyFlowColors.WarningBg else StudyFlowColors.SageSurface
    val borderColor = if (isWarm) StudyFlowColors.WarningBorder else StudyFlowColors.SageBorder
    val textColor = if (isWarm) StudyFlowColors.WarningText else StudyFlowColors.TextPrimary
    val actionColor = if (isWarm) StudyFlowColors.WarningText else StudyFlowColors.ForestGreen

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        color = bgColor,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium,
                color = textColor,
                modifier = Modifier.weight(1f)
            )
            if (actionLabel != null && onActionClick != null) {
                Spacer(modifier = Modifier.width(10.dp))
                TextButton(
                    onClick = onActionClick,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = actionLabel,
                        style = MaterialTheme.typography.labelLarge,
                        color = actionColor
                    )
                }
            }
        }
    }
}

@Composable
private fun MinimalSubjectRow(
    block: StudyBlockEntity,
    onClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val tier = block.toCognitiveTier()
    val isCompleted = block.status == BlockStatus.COMPLETED
    val circleColor = if (isCompleted) {
        tier.accentColor().copy(alpha = 0.22f)
    } else {
        tier.accentColor()
    }
    val timeText = if (block.actualMinutes > 0) {
        formatMinutesAsHms(block.actualMinutes)
    } else {
        "${block.plannedMinutes} мин"
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !isCompleted, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Слева: круглый цветной значок Play (или галочка для завершённых)
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(circleColor),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isCompleted) Icons.Rounded.Check else Icons.Rounded.PlayArrow,
                contentDescription = if (isCompleted) "Завершено" else "Старт",
                tint = if (isCompleted) tier.accentColor() else Color.White,
                modifier = Modifier.size(22.dp)
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        // По центру: название предмета и короткая спокойная подпись при необходимости
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = block.title,
                style = MaterialTheme.typography.titleMedium,
                color = if (isCompleted) StudyFlowColors.TextMuted else StudyFlowColors.TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            val metaParts = buildList {
                add(tier.shortLabel())
                if (block.status == BlockStatus.DOWNGRADED) {
                    add("облегчено")
                } else if (isCompleted) {
                    add("готово")
                }
            }.joinToString(" · ")

            Text(
                text = metaParts,
                style = MaterialTheme.typography.labelMedium,
                color = StudyFlowColors.TextMuted
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        // Справа: время в табличных цифрах (0:00:00 или 50 мин)
        Text(
            text = timeText,
            style = MaterialTheme.typography.titleMedium.copy(
                fontFeatureSettings = "tnum",
                fontWeight = FontWeight.Medium
            ),
            color = if (isCompleted) StudyFlowColors.TextMuted else StudyFlowColors.TextPrimary
        )

        if (!isCompleted) {
            IconButton(
                onClick = onDeleteClick,
                modifier = Modifier
                    .padding(start = 2.dp)
                    .size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Delete,
                    contentDescription = "Удалить",
                    tint = StudyFlowColors.TextMuted.copy(alpha = 0.7f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun DailySummaryTab(
    uiState: StudyUiState
) {
    val tier1Minutes = uiState.minutesForTier(CognitiveTier.TIER_1)
    val tier2Minutes = uiState.minutesForTier(CognitiveTier.TIER_2)
    val tier3Minutes = uiState.minutesForTier(CognitiveTier.TIER_3)
    val remainingHardMinutes = uiState.tier1Overload.remainingMinutes
    val hardLimit = uiState.tier1Overload.limitMinutes
    val closureNotes = remember(uiState.blocks) {
        uiState.blocks.filter { it.closureNote.isNotBlank() }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudyFlowColors.PureWhite),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Две крупные шалфейные карточки с гигантскими цифрами по центру
        item(key = "summary_big_metrics") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SummaryBigNumberCard(
                    modifier = Modifier.weight(1f),
                    title = "Минут за день",
                    value = uiState.totalMinutesToday.toString(),
                    caption = "всего учёбы"
                )
                SummaryBigNumberCard(
                    modifier = Modifier.weight(1f),
                    title = "Запас сложного",
                    value = remainingHardMinutes.toString(),
                    caption = if (hardLimit == 0) {
                        "день отдыха"
                    } else {
                        "из $hardLimit мин"
                    }
                )
            }
        }

        // Простая разбивка по видам нагрузки: Сложное / Практика / Лёгкое
        item(key = "summary_breakdown") {
            SageCard {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(
                        text = "Распределение за день",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = StudyFlowColors.TextPrimary
                    )

                    val maxRef = maxOf(
                        hardLimit,
                        tier1Minutes,
                        tier2Minutes,
                        tier3Minutes,
                        60
                    ).toFloat()

                    SimpleTierBarRow(
                        label = CognitiveTier.TIER_1.shortLabel(),
                        minutes = tier1Minutes,
                        suffix = if (hardLimit > 0) " / $hardLimit мин" else " мин",
                        progress = if (hardLimit > 0) {
                            (tier1Minutes / hardLimit.toFloat()).coerceIn(0f, 1f)
                        } else {
                            1f
                        },
                        color = CognitiveTier.TIER_1.accentColor()
                    )

                    SimpleTierBarRow(
                        label = CognitiveTier.TIER_2.shortLabel(),
                        minutes = tier2Minutes,
                        suffix = " мин",
                        progress = (tier2Minutes / maxRef).coerceIn(0f, 1f),
                        color = CognitiveTier.TIER_2.accentColor()
                    )

                    SimpleTierBarRow(
                        label = CognitiveTier.TIER_3.shortLabel(),
                        minutes = tier3Minutes,
                        suffix = " мин",
                        progress = (tier3Minutes / maxRef).coerceIn(0f, 1f),
                        color = CognitiveTier.TIER_3.accentColor()
                    )
                }
            }
        }

        // Список заметок остановки на завтра
        item(key = "summary_notes") {
            SageCard {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Заметки на завтра",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = StudyFlowColors.TextPrimary
                    )

                    if (closureNotes.isEmpty()) {
                        Text(
                            text = "Здесь появятся ваши короткие заметки после каждого учебного блока — чтобы завтра сразу продолжить с нужного места.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = StudyFlowColors.TextSecondary
                        )
                    } else {
                        closureNotes.forEachIndexed { index, block ->
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(block.toCognitiveTier().accentColor())
                                    )
                                    Text(
                                        text = block.title,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = StudyFlowColors.TextPrimary
                                    )
                                }
                                Text(
                                    text = block.closureNote,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = StudyFlowColors.TextSecondary,
                                    modifier = Modifier.padding(start = 16.dp)
                                )
                            }
                            if (index < closureNotes.lastIndex) {
                                HorizontalDivider(
                                    color = StudyFlowColors.SageBorder,
                                    thickness = 0.75.dp
                                )
                            }
                        }
                    }
                }
            }
        }

        item(key = "summary_bottom_spacer") {
            Spacer(modifier = Modifier.navigationBarsPadding())
        }
    }
}

@Composable
private fun SageCard(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = StudyFlowColors.SageSurface,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, StudyFlowColors.SageBorder)
    ) {
        Box(modifier = Modifier.padding(18.dp)) {
            content()
        }
    }
}

@Composable
private fun SummaryBigNumberCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    caption: String
) {
    Surface(
        modifier = modifier,
        color = StudyFlowColors.SageSurface,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, StudyFlowColors.SageBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = StudyFlowColors.TextSecondary,
                textAlign = TextAlign.Center
            )
            Text(
                text = value,
                style = MaterialTheme.typography.displayMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontFeatureSettings = "tnum"
                ),
                color = StudyFlowColors.ForestGreen
            )
            Text(
                text = caption,
                style = MaterialTheme.typography.labelMedium,
                color = StudyFlowColors.TextMuted,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun SimpleTierBarRow(
    label: String,
    minutes: Int,
    suffix: String,
    progress: Float,
    color: Color
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(color)
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyLarge,
                    color = StudyFlowColors.TextPrimary
                )
            }
            Text(
                text = "$minutes$suffix",
                style = MaterialTheme.typography.labelLarge.copy(fontFeatureSettings = "tnum"),
                color = StudyFlowColors.TextPrimary
            )
        }

        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(999.dp)),
            color = color,
            trackColor = StudyFlowColors.SageBorder,
            strokeCap = StrokeCap.Round
        )
    }
}

@Composable
private fun SleepQualityDialog(
    initialQuality: Int,
    onDismiss: () -> Unit,
    onSave: (Int) -> Unit
) {
    var selected by rememberSaveable { mutableIntStateOf(initialQuality.coerceIn(1, 5)) }
    val limitPreview = RuleEngine.calculateTier1DailyLimit(sleepQuality = selected)
    val isLowSleep = selected <= RuleEngine.POOR_SLEEP_THRESHOLD

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudyFlowColors.PureWhite,
        shape = RoundedCornerShape(22.dp),
        title = {
            Text(
                text = "Как вы спали?",
                style = MaterialTheme.typography.headlineSmall,
                color = StudyFlowColors.TextPrimary
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(
                    text = "От сна зависит, сколько сложных задач сегодня будет комфортно выполнить.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = StudyFlowColors.TextSecondary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    (1..5).forEach { score ->
                        val isSelected = selected == score
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isSelected) {
                                        StudyFlowColors.ForestGreen
                                    } else {
                                        StudyFlowColors.SageSurface
                                    }
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) {
                                        StudyFlowColors.ForestGreen
                                    } else {
                                        StudyFlowColors.SageBorder
                                    },
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { selected = score },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = score.toString(),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) Color.White else StudyFlowColors.TextPrimary
                            )
                        }
                    }
                }

                Text(
                    text = if (isLowSleep) {
                        "Щадящий режим: запас сложных задач на сегодня — $limitPreview мин."
                    } else {
                        "Полный запас сил: до $limitPreview мин сложных задач сегодня."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (isLowSleep) StudyFlowColors.WarningText else StudyFlowColors.TextSecondary
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(selected) },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = StudyFlowColors.ForestGreen,
                    contentColor = Color.White
                )
            ) {
                Text("Сохранить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена", color = StudyFlowColors.TextSecondary)
            }
        }
    )
}

@Composable
private fun AddSubjectDialog(
    isHardBlocked: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (title: String, tier: CognitiveTier, plannedMinutes: Int) -> Unit
) {
    var title by rememberSaveable { mutableStateOf("") }
    var selectedTier by remember {
        mutableStateOf(if (isHardBlocked) CognitiveTier.TIER_2 else CognitiveTier.TIER_1)
    }
    var durationSlider by rememberSaveable { mutableFloatStateOf(50f) }
    val plannedMinutes = durationSlider.roundToInt().coerceIn(
        RuleEngine.MIN_WORK_DURATION_MINUTES,
        RuleEngine.MAX_WORK_DURATION_MINUTES
    )
    val breakMinutes = RuleEngine.calculateRecommendedBreakSeconds(plannedMinutes) / 60

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudyFlowColors.PureWhite,
        shape = RoundedCornerShape(22.dp),
        title = {
            Text(
                text = "Новый предмет",
                style = MaterialTheme.typography.headlineSmall,
                color = StudyFlowColors.TextPrimary
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Название предмета") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StudyFlowColors.ForestGreen,
                        unfocusedBorderColor = StudyFlowColors.SageBorder,
                        focusedLabelColor = StudyFlowColors.ForestGreen,
                        cursorColor = StudyFlowColors.ForestGreen,
                        focusedTextColor = StudyFlowColors.TextPrimary,
                        unfocusedTextColor = StudyFlowColors.TextPrimary
                    )
                )

                // Простые русские чипы: «Сложное», «Практика», «Лёгкое»
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Сложность",
                        style = MaterialTheme.typography.labelLarge,
                        color = StudyFlowColors.TextPrimary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CognitiveTier.entries.forEach { tier ->
                            val isSelected = selectedTier == tier
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (isSelected) {
                                            tier.softBackgroundColor()
                                        } else {
                                            StudyFlowColors.SageSurface
                                        }
                                    )
                                    .border(
                                        width = if (isSelected) 1.5.dp else 1.dp,
                                        color = if (isSelected) {
                                            tier.accentColor()
                                        } else {
                                            StudyFlowColors.SageBorder
                                        },
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .clickable { selectedTier = tier }
                                    .padding(vertical = 11.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = tier.shortLabel(),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (isSelected) {
                                        tier.accentColor()
                                    } else {
                                        StudyFlowColors.TextSecondary
                                    }
                                )
                            }
                        }
                    }

                    val noteText = if (selectedTier == CognitiveTier.TIER_1 && isHardBlocked) {
                        "Лимит сложного на сегодня исчерпан — предмет сохранится как «Практика»."
                    } else {
                        selectedTier.humanHint()
                    }
                    Text(
                        text = noteText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (selectedTier == CognitiveTier.TIER_1 && isHardBlocked) {
                            StudyFlowColors.WarningText
                        } else {
                            StudyFlowColors.TextSecondary
                        }
                    )
                }

                // Слайдер длительности блока 50–80 мин
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Длительность",
                            style = MaterialTheme.typography.labelLarge,
                            color = StudyFlowColors.TextPrimary
                        )
                        Text(
                            text = "$plannedMinutes мин · перерыв $breakMinutes мин",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontFeatureSettings = "tnum"
                            ),
                            color = StudyFlowColors.ForestGreen
                        )
                    }

                    Slider(
                        value = durationSlider,
                        onValueChange = { durationSlider = it },
                        valueRange = RuleEngine.MIN_WORK_DURATION_MINUTES.toFloat()..
                            RuleEngine.MAX_WORK_DURATION_MINUTES.toFloat(),
                        steps = 5,
                        colors = SliderDefaults.colors(
                            thumbColor = StudyFlowColors.ForestGreen,
                            activeTrackColor = StudyFlowColors.ForestGreen,
                            inactiveTrackColor = StudyFlowColors.SageBorder
                        )
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(title, selectedTier, plannedMinutes) },
                enabled = title.trim().isNotEmpty(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = StudyFlowColors.ForestGreen,
                    contentColor = Color.White
                )
            ) {
                Text("Добавить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена", color = StudyFlowColors.TextSecondary)
            }
        }
    )
}

@Composable
private fun PreStartFeelingDialog(
    block: StudyBlockEntity,
    onDismiss: () -> Unit,
    onSelectAndStart: (Int) -> Unit
) {
    val options = listOf(
        1 to "Совсем нет сил",
        2 to "Немного устал",
        3 to "Нормально",
        4 to "Бодро",
        5 to "Отлично"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudyFlowColors.PureWhite,
        shape = RoundedCornerShape(22.dp),
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = "Как самочувствие?",
                    style = MaterialTheme.typography.headlineSmall,
                    color = StudyFlowColors.TextPrimary
                )
                Text(
                    text = "${block.title} · ${block.plannedMinutes} мин",
                    style = MaterialTheme.typography.bodyMedium,
                    color = StudyFlowColors.TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                options.forEach { (level, label) ->
                    Surface(
                        onClick = { onSelectAndStart(level) },
                        color = StudyFlowColors.SageSurface,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, StudyFlowColors.SageBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = level.toString(),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = StudyFlowColors.ForestGreen
                                )
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = StudyFlowColors.TextPrimary
                                )
                            }
                            Icon(
                                imageVector = Icons.Rounded.PlayArrow,
                                contentDescription = null,
                                tint = StudyFlowColors.ForestGreen,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена", color = StudyFlowColors.TextSecondary)
            }
        }
    )
}

@Composable
private fun CrescentMoonIcon(
    color: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val radius = size.minDimension / 2f
        val center = Offset(size.width / 2f, size.height / 2f)
        drawCircle(color = color, radius = radius, center = center)
        drawCircle(
            color = StudyFlowColors.ForestGreen,
            radius = radius * 0.82f,
            center = Offset(center.x + radius * 0.42f, center.y - radius * 0.22f)
        )
    }
}

private fun resolveSingleOverloadHint(uiState: StudyUiState): String? {
    return when {
        uiState.energyDropEvaluation.action == EnergyAdaptationAction.SHORTEN_DAY_OR_STOP ->
            "Силы заметно снизились — лучше облегчить оставшийся план или завершить день."

        uiState.energyDropEvaluation.action == EnergyAdaptationAction.DOWNGRADE_NEXT_TASKS ->
            "Энергия снижается два блока подряд — стоит перевести следующие предметы в более лёгкий режим."

        uiState.deloadEvaluation.isDeloadRecommended ->
            "${uiState.deloadEvaluation.consecutiveWorkDays}-й день подряд без перерыва — сегодня лучше обойтись без сложных задач."

        uiState.tier1Overload.isTier1Blocked ->
            "Лимит сложных задач на сегодня исчерпан — дальше лучше переключиться на практику или лёгкий обзор."

        else -> null
    }
}

private fun sanitizeSystemMessage(raw: String): String {
    return raw
        .replace("TIER_1", "сложных задач")
        .replace("TIER_2", "«Практику»")
        .replace("TIER_3", "«Лёгкое»")
}

private fun formatMinutesAsHms(totalMinutes: Int): String {
    val safe = totalMinutes.coerceAtLeast(0)
    val hours = safe / 60
    val minutes = safe % 60
    return String.format(Locale.US, "%d:%02d:00", hours, minutes)
}

private fun formatHumanDate(dateIso: String): String {
    return runCatching {
        val parsed = LocalDate.parse(dateIso)
        val formatter = DateTimeFormatter.ofPattern("d MMMM, EEE", Locale("ru"))
        parsed.format(formatter)
    }.getOrDefault(dateIso)
}
