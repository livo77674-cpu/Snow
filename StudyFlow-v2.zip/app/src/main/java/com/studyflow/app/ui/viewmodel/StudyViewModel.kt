// ПУТЬ: com/studyflow/app/ui/viewmodel/StudyViewModel.kt

package com.studyflow.app.ui.viewmodel

import android.content.Context
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.studyflow.app.data.local.AppDatabase
import com.studyflow.app.data.local.DailyStateEntity
import com.studyflow.app.data.local.StudyBlockEntity
import com.studyflow.app.data.local.StudyDao
import com.studyflow.app.data.local.TierMinutesSummary
import com.studyflow.app.domain.engine.DeloadEvaluation
import com.studyflow.app.domain.engine.EnergyDropEvaluation
import com.studyflow.app.domain.engine.RuleEngine
import com.studyflow.app.domain.engine.Tier1OverloadResult
import com.studyflow.app.domain.model.BlockStatus
import com.studyflow.app.domain.model.CognitiveTier
import com.studyflow.app.service.TimerForegroundService
import com.studyflow.app.service.TimerSnapshot
import com.studyflow.app.service.TimerStateHolder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

/**
 * Единое реактивное состояние экранов StudyFlow.
 */
data class StudyUiState(
    val todayDate: String = LocalDate.now().toString(),
    val isLoading: Boolean = true,
    val dailyState: DailyStateEntity? = null,
    val blocks: List<StudyBlockEntity> = emptyList(),
    val minutesByTier: Map<CognitiveTier, Int> = emptyMap(),
    val tier1Overload: Tier1OverloadResult = RuleEngine.checkTier1Overload(
        tier1ActualMinutesToday = 0,
        tier1LimitMinutes = RuleEngine.BASE_TIER1_LIMIT_MINUTES
    ),
    val energyDropEvaluation: EnergyDropEvaluation = RuleEngine.evaluateEnergyTrend(emptyList()),
    val deloadEvaluation: DeloadEvaluation = RuleEngine.evaluateDeloadNeed(0),
    val timerSnapshot: TimerSnapshot = TimerSnapshot(),
    val snackbarMessage: String? = null
) {
    val totalMinutesToday: Int
        get() = minutesByTier.values.sum()

    fun minutesForTier(tier: CognitiveTier): Int = minutesByTier[tier] ?: 0

    /**
     * Активный учебный блок, если таймер запущен и блок найден в списке на сегодня.
     */
    val activeBlock: StudyBlockEntity?
        get() = timerSnapshot.activeBlockId?.let { activeId ->
            blocks.firstOrNull { it.id == activeId }
        }
}

/**
 * ViewModel приложения StudyFlow.
 *
 * Связывает локальную БД Room ([StudyDao]), чистый движок адаптивных правил ([RuleEngine])
 * и состояние фонового таймера ([TimerStateHolder] / [TimerForegroundService]).
 */
@OptIn(ExperimentalCoroutinesApi::class)
class StudyViewModel(
    private val studyDao: StudyDao
) : ViewModel() {

    private val currentDateFlow = MutableStateFlow(LocalDate.now().toString())
    private val snackbarMessageFlow = MutableStateFlow<String?>(null)

    private val dailyStateFlow = currentDateFlow.flatMapLatest { date ->
        studyDao.observeDailyState(date)
    }

    private val blocksFlow = currentDateFlow.flatMapLatest { date ->
        studyDao.observeBlocksForDate(date)
    }

    private val minutesByTierFlow = currentDateFlow.flatMapLatest { date ->
        studyDao.observeActualMinutesByTier(date)
    }

    private val databaseStateFlow = combine(
        currentDateFlow,
        dailyStateFlow,
        blocksFlow,
        minutesByTierFlow
    ) { date, dailyState, blocks, tierSummaries ->
        DatabaseProjection(
            date = date,
            dailyState = dailyState,
            blocks = blocks,
            tierSummaries = tierSummaries
        )
    }

    val uiState: StateFlow<StudyUiState> = combine(
        databaseStateFlow,
        TimerStateHolder.state,
        snackbarMessageFlow
    ) { dbProjection, timerSnapshot, message ->
        val minutesMap = buildTierMinutesMap(dbProjection.tierSummaries)
        val tier1ActualMinutes = minutesMap[CognitiveTier.TIER_1] ?: 0
        val tier1Limit = dbProjection.dailyState?.tier1LimitMinutes
            ?: RuleEngine.BASE_TIER1_LIMIT_MINUTES

        val tier1Overload = RuleEngine.checkTier1Overload(
            tier1ActualMinutesToday = tier1ActualMinutes,
            tier1LimitMinutes = tier1Limit
        )
        val energyEvaluation = RuleEngine.evaluateEnergyTrend(dbProjection.blocks)
        val deloadEvaluation = RuleEngine.evaluateDeloadNeed(
            consecutiveWorkDays = dbProjection.dailyState?.consecutiveWorkDays ?: 0
        )

        StudyUiState(
            todayDate = dbProjection.date,
            isLoading = false,
            dailyState = dbProjection.dailyState,
            blocks = dbProjection.blocks,
            minutesByTier = minutesMap,
            tier1Overload = tier1Overload,
            energyDropEvaluation = energyEvaluation,
            deloadEvaluation = deloadEvaluation,
            timerSnapshot = timerSnapshot,
            snackbarMessage = message
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = StudyUiState()
    )

    /**
     * Обновляет текущую дату, если приложение оставалось открытым при переходе через полночь.
     */
    fun refreshDateIfNeeded() {
        val actualToday = LocalDate.now().toString()
        if (currentDateFlow.value != actualToday) {
            currentDateFlow.value = actualToday
        }
    }

    /**
     * Сохраняет утреннюю оценку качества сна (1..5):
     * - Вычисляет серию рабочих дней подряд на основе вчерашней записи в БД.
     * - Проверяет необходимость Deload-дня через [RuleEngine.evaluateDeloadNeed].
     * - Рассчитывает дневной лимит TIER_1 через [RuleEngine.calculateTier1DailyLimit].
     * - Записывает [DailyStateEntity] в Room.
     */
    fun saveMorningSleepCheckIn(sleepQuality: Int) {
        val normalizedSleep = sleepQuality.coerceIn(
            DailyStateEntity.MIN_SLEEP_QUALITY,
            DailyStateEntity.MAX_SLEEP_QUALITY
        )
        val today = currentDateFlow.value

        viewModelScope.launch(Dispatchers.IO) {
            val existingToday = studyDao.getDailyState(today)
            val consecutiveWorkDays = if (existingToday != null) {
                existingToday.consecutiveWorkDays
            } else {
                val yesterdayDate = LocalDate.parse(today).minusDays(1).toString()
                val yesterdayState = studyDao.getDailyState(yesterdayDate)
                when {
                    yesterdayState == null -> 1
                    yesterdayState.deloadSuggested -> 1
                    else -> yesterdayState.consecutiveWorkDays.coerceAtLeast(1) + 1
                }
            }

            val deloadEvaluation = RuleEngine.evaluateDeloadNeed(consecutiveWorkDays)
            val tier1Limit = RuleEngine.calculateTier1DailyLimit(
                sleepQuality = normalizedSleep,
                isDeloadDay = deloadEvaluation.isDeloadRecommended
            )

            val entity = DailyStateEntity(
                date = today,
                sleepQuality = normalizedSleep,
                tier1LimitMinutes = tier1Limit,
                consecutiveWorkDays = consecutiveWorkDays,
                deloadSuggested = deloadEvaluation.isDeloadRecommended
            )
            studyDao.upsertDailyState(entity)
        }
    }

    /**
     * Добавляет новый учебный блок на сегодня.
     * Если пользователь выбрал [CognitiveTier.TIER_1], но лимит исчерпан (или активен Deload),
     * блок автоматически понижается до [CognitiveTier.TIER_2].
     */
    fun addStudyBlock(
        title: String,
        tier: CognitiveTier,
        plannedMinutes: Int
    ) {
        val cleanTitle = title.trim()
        if (cleanTitle.isEmpty()) return

        val today = currentDateFlow.value
        val safeMinutes = RuleEngine.clampWorkDurationMinutes(plannedMinutes)

        viewModelScope.launch(Dispatchers.IO) {
            val dailyState = studyDao.getDailyState(today)
            val tier1Limit = dailyState?.tier1LimitMinutes ?: RuleEngine.BASE_TIER1_LIMIT_MINUTES
            val tier1Actual = studyDao.getActualMinutesForTier(
                date = today,
                tier = CognitiveTier.TIER_1.level
            )

            val overload = RuleEngine.checkTier1Overload(
                tier1ActualMinutesToday = tier1Actual,
                tier1LimitMinutes = tier1Limit
            )

            val effectiveTier = if (tier == CognitiveTier.TIER_1 && overload.isTier1Blocked) {
                CognitiveTier.TIER_2
            } else {
                tier
            }

            val initialStatus = if (effectiveTier != tier) {
                BlockStatus.DOWNGRADED
            } else {
                BlockStatus.PLANNED
            }

            val newBlock = StudyBlockEntity(
                date = today,
                title = cleanTitle,
                tier = effectiveTier.level,
                plannedMinutes = safeMinutes,
                status = initialStatus
            )
            studyDao.insertBlock(newBlock)

            if (effectiveTier != tier) {
                snackbarMessageFlow.value =
                    "Лимит TIER_1 исчерпан: задача «$cleanTitle» автоматически переведена в TIER_2."
            }
        }
    }

    /**
     * Удаляет запланированный учебный блок.
     */
    fun deleteStudyBlock(block: StudyBlockEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            studyDao.deleteBlock(block)
        }
    }

    /**
     * Сохраняет предсессионную оценку энергии (`energyBefore`) в блок и запускает
     * фоновый [TimerForegroundService] через [ContextCompat.startForegroundService].
     */
    fun startBlock(
        context: Context,
        block: StudyBlockEntity,
        energyBefore: Int
    ) {
        val appContext = context.applicationContext
        val clampedEnergy = energyBefore.coerceIn(1, 5)

        viewModelScope.launch {
            val updatedBlock = block.copy(energyBefore = clampedEnergy)
            withContext(Dispatchers.IO) {
                studyDao.updateBlock(updatedBlock)
            }

            val startIntent = TimerForegroundService.createStartBlockIntent(
                context = appContext,
                blockId = updatedBlock.id,
                title = updatedBlock.title,
                tier = updatedBlock.toCognitiveTier(),
                plannedMinutes = updatedBlock.plannedMinutes,
                initialDistractions = updatedBlock.distractionCount
            )
            try {
                ContextCompat.startForegroundService(appContext, startIntent)
            } catch (e: Exception) {
                Log.e(TAG, "Ошибка запуска TimerForegroundService для блока ${updatedBlock.id}", e)
                snackbarMessageFlow.value = "Не удалось запустить фоновый таймер."
            }
        }
    }

    /**
     * Отправляет управляющую команду в запущенный [TimerForegroundService].
     */
    fun sendTimerCommand(
        context: Context,
        action: String
    ) {
        val appContext = context.applicationContext
        val commandIntent = TimerForegroundService.createActionIntent(appContext, action)
        try {
            appContext.startService(commandIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Ошибка отправки команды $action в TimerForegroundService", e)
        }
    }

    /**
     * Сохраняет заметку из 3-минутного буфера закрытия (фаза CLOSURE) в Room.
     */
    fun saveClosureNote(blockId: Long, note: String) {
        viewModelScope.launch(Dispatchers.IO) {
            studyDao.updateClosureNote(
                blockId = blockId,
                closureNote = note.trim()
            )
        }
    }

    /**
     * Завершает фазу POST_CHECKIN: сохраняет итоговую оценку энергии и статус COMPLETED,
     * после чего переводит таймер обратно в состояние IDLE.
     */
    fun submitPostCheckIn(blockId: Long, energyAfter: Int) {
        val clampedEnergy = energyAfter.coerceIn(1, 5)
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                studyDao.completePostCheckIn(
                    blockId = blockId,
                    energyAfter = clampedEnergy,
                    status = BlockStatus.COMPLETED
                )
            }
            TimerStateHolder.reset()
        }
    }

    /**
     * Понижает когнитивный эшелон всех оставшихся запланированных (`PLANNED`) блоков
     * на сегодня через [StudyDao.downgradeBlockTier].
     */
    fun applyEnergyAdaptation(blocks: List<StudyBlockEntity>) {
        val plannedBlocks = blocks.filter { it.status == BlockStatus.PLANNED }
        if (plannedBlocks.isEmpty()) {
            snackbarMessageFlow.value = "Нет запланированных блоков для облегчения."
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            var downgradedCount = 0
            plannedBlocks.forEach { block ->
                val currentTier = block.toCognitiveTier()
                val nextTier = RuleEngine.downgradeTier(currentTier)
                studyDao.downgradeBlockTier(
                    blockId = block.id,
                    newTier = nextTier.level,
                    status = BlockStatus.DOWNGRADED
                )
                downgradedCount++
            }
            snackbarMessageFlow.value = "Облегчено задач: $downgradedCount."
        }
    }

    /**
     * Сбрасывает одноразовое информационное сообщение после показа в Snackbar.
     */
    fun clearSnackbarMessage() {
        snackbarMessageFlow.value = null
    }

    private fun buildTierMinutesMap(summaries: List<TierMinutesSummary>): Map<CognitiveTier, Int> {
        val result = mutableMapOf(
            CognitiveTier.TIER_1 to 0,
            CognitiveTier.TIER_2 to 0,
            CognitiveTier.TIER_3 to 0
        )
        summaries.forEach { item ->
            result[CognitiveTier.fromLevel(item.tier)] = item.totalMinutes.coerceAtLeast(0)
        }
        return result
    }

    private data class DatabaseProjection(
        val date: String,
        val dailyState: DailyStateEntity?,
        val blocks: List<StudyBlockEntity>,
        val tierSummaries: List<TierMinutesSummary>
    )

    companion object {
        private const val TAG = "StudyViewModel"
    }
}

/**
 * Фабрика для создания [StudyViewModel] с привязкой к локальному Singleton [AppDatabase].
 */
class StudyViewModelFactory(
    private val context: Context
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(StudyViewModel::class.java)) {
            val dao = AppDatabase.getInstance(context.applicationContext).studyDao()
            return StudyViewModel(dao) as T
        }
        throw IllegalArgumentException("Неизвестный класс ViewModel: ${modelClass.name}")
    }
}
